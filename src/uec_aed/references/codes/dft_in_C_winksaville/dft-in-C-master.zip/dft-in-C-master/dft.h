#include <stdint.h>

void dft(float x[], float result[], uint32_t num_elems);
