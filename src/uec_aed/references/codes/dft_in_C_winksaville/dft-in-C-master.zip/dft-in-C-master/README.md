# Compute Descrete Fouier Transform (DFT)

Licensed under UNLICENSE

See https://en.wikipedia.org/wiki/Discrete_Fourier_transform and
https://batchloaf.wordpress.com/2013/12/07/simple-dft-in-c/

# test
Currently no real tests we only compile properly
```
make
```
