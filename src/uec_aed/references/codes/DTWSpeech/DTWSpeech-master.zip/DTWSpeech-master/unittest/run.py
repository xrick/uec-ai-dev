import unittest
from unittest1 import CalTest1
from unittest2 import CalTest2

if __name__ == "__main__":
    unittest.main()